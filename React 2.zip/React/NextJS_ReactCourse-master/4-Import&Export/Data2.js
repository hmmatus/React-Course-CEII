/**
 * Base exporting
 */

const date = new Date();

const add = (a, b) => {
    return a + b;
}

const sub = (a, b) => {
    return a - b;
}

export {date, add, sub}