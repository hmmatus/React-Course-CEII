import React, { Component } from 'react';
import './App.css';
import {Form} from "./form/form"

const credentials={
  username:"matus",
  pass:"1234",
}
class App extends Component {
  constructor(props) {
    super(props)

    this.state = {
      username: "",
      pass:"",
      logged:false,
    }
  }

  submitHandler=event=>{
    event.preventDefault();
    const { username,pass } = this.state;
    console.log("Entro")
    if (username ===credentials.username && pass===credentials.pass){
      this.setState({
        logged:true,
      })
      console.log("Loggeadp")
    }
}
changeHandler=event=>{
    const id = event.target.id;
    const value = event.target.value;
    console.log(id + value)
    this.setState({[id]:value})
}
  render(){
    const {username,pass} = this.state;
    return(
      <div className="App">
        {!this.state.logged?
        <Form
        username={username}
        pass={pass}
        changeHandler={this.changeHandler}
        submitHandler={this.submitHandler} />:<h1>Estas loggeado</h1>}
      </div>
    )
  }
}

export default App;
