import React from 'react';

export const Form = (props) => {
    const {name,text,image,changeHandler,submitHandler} = props;
    return (
        <form onSubmit={submitHandler}>
            <input onChange={changeHandler} id="name" placeholder="Name" value={name} />
            <textarea onChange={changeHandler} id="text" placeholder="Description" value={text}/>
            <input onChange={changeHandler} id="image" placeholder="Url" value={image}/>
            <input type="hidden" id="likes" value={0}/>
            <button type="submit">Guardar</button>
        </form>
    )
}