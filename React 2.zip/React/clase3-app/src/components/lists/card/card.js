import React from 'react';
import '../../../App.css';


const Card = props => {
    return (
        <div className="posts">
            <section>
                <h2>{props.name}</h2>
                <p>{props.text}</p>
                <img src={props.image} alt={props.name} />
                <p className="likes">Numero de likes: {props.likes}</p>
                <button onClick={props.onEvent}>Like</button>
            </section>
        </div>
    )
}


export default Card;