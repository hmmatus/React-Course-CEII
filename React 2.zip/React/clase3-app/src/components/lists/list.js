import React from 'react'
import '../../App.css'
import Card from './card/card'

export const List = props => {
    return (
        <div className="listContainer">
            {props.posts.map((post, index) => (            
                <Card
                    key={index}
                    {...post}
                    deleteHandler={() => props.deleteHandler(index)}
                    onEvent = {()=>props.addLikes(post.id)}
                />
            ))}
        </div>
    )
}