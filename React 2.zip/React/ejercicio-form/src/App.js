import React, { Component } from 'react'
import { container } from './App.module.css'
import {Form} from './components/Form/Form'
import {List} from './components/List/List'


class App extends Component {
      constructor(props) {
            super(props);
            this.state = { ...initState, peoples: [] }
            this.submitHandler = this.submitHandler.bind(this);
            this.changeHandler = this.changeHandler.bind(this);
            this.deleteHandler = this.deleteHandler.bind(this);

      }
      submitHandler(event) {
            event.preventDefault();
            const { name, lastName, age, carnet } = this.state;
            const peoples = [...this.state.peoples];
            peoples.push({
                  name, lastName, age, carnet
            });
            this.setState({
                  ...initState,
                  peoples
            })
      }
      changeHandler(event){
            console.log(this.state.peoples);
            const id = event.target.id;
            const value = event.target.value;
            this.setState({
                  [id]:value
            })
      }
      deleteHandler(delIndex){
            const newPeoples = this.state.peoples.filter((person,index)=>{
                  return delIndex !== index;
            })
            this.setState({
                  peoples:newPeoples
            })
      }
      render() {
            const {name,lastName,age,carnet,peoples} = this.state;
            return (
                  <div className={container}>
                        <Form 
                              name={name}
                              lastName={lastName}
                              age={age}
                              carnet={carnet}
                              changeHandler={this.changeHandler}
                              submitHandler={this.submitHandler}
                        />
                        <List peoples={peoples} deleteHandler={this.deleteHandler} />
                  </div>
            )
      }
}

export default App;
