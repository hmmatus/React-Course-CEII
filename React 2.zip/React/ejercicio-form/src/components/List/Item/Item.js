import React from 'react'
import { container,sub,deleteBtn } from './Item.module.css'


export const Item = props => {
  const { name, lastName, age,carnet,deleteHandler} = props;
  return (
    <div className={container}>
      <div className={sub}>
        <h4>{`${name} ${lastName}`}</h4>
        <span
          onClick={deleteHandler}
          className={deleteBtn}
        >
          x
        </span>
      </div>
      <div className={sub}>
        <span>Edad: {age}</span>
        <span>Carnet:{carnet}</span>
      </div>
    </div>
  )
}

