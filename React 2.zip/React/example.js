/*const example = person => {
    console.log("First name: "+person.name);
    console.log("Last name: "+person.lastname);
    console.log("Gender: "+person.gender);
    console.log("First name: "+person.age);

}

example(
    {
        name:"Hector",
        lastname:"Matus",
        gender:"M",
        age:23,
    }
)

export default example;*/

const spreadFun=(arreglo)=>{
    let newArr=[];
    let oldArr=arreglo;
    for (let index = 0;index<10; index++) {
        newArr = [index,...newArr,index]
    }
    console.log(newArr)
}

spreadFun();