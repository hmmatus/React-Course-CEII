import React from 'react';
import './App.css';
import Card from './Components/card';

const Arr = [
  {
    name:"Hector Matus",
    career:"Ing. Informatica"
  },
  {
    name:"Jose Rivera",
    career:"Ing. Insdustrial"
  },
  {
    name:"Mauricio Trejo",
    career:"Ing. Informatica"
  }
];


export const renderItem=(item)=>{
  console.log(item);
  return(
    <Card name={item.name} career={item.career}/>
  )
}

function App() {
  return (
    <div className="App">
      <h1>Hola mundo!</h1>
      <Card />
    </div>
  );
}

export default App;
