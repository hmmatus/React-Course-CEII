import React, { Component } from 'react';
import "../App.css"

/*const Card=props=>{
  return(
    <div className="Card">
      <section>
        <h2>Mi nombre es {props.name}</h2>
        <p>Estudio {props.career}</p>
      </section>
    </div>
  );
}*/
class Card extends Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [
        {
          id:1,
          name: "Hector Matus",
          career: "Ing. Informatica"
        },
        {
          id:2,
          name: "Jose Rivera",
          career: "Ing. Insdustrial"
        },
        {
          id:3,
          name: "Mauricio Trejo",
          career: "Ing. Informatica"
        }
      ]
    }
  }
  addElement=(element)=>{
    this.setState({persons:[...this.state.persons,element]},()=>{
      console.log(this.state.persons);
    });
  }
  renderItems = () => {
    return this.state.persons.map(element => {
      return (
        <div className="Card">
          <section>
            <h2>Mi nombre es {element.name}</h2>
            <p>Estudio {element.career}</p>
            <button onClick={()=>this.addElement(element)}>Press me!</button>
          </section>
        </div>
      )
    })
  }

  render() {
    return (
      <div>
        {this.renderItems()}
      </div>
    )
  }
}

export default Card;
