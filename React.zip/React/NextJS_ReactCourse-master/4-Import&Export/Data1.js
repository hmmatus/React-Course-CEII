/**
 * Default exporting
 */

const cpu = {
    cores: 6,
    baseSpeed: 2.33,
}

export default cpu;