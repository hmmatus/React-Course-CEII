import React from 'react'
import styled from 'styled-components'

export const Button1 = styled.button`
    background-color:${props=>props.primary?"blue":"indigo"};
    color:${props=>props.primary?"tomato":"white"};
    border-radius:0.4em;
    font-size:30px;
    transition:ease all 0.4s;
    &:hover{
        background-color:teal;
    }
    &:focus{
        outline:none;
    }
`

export const OtherButton = styled(Button1)`
    color:white;
    background-color:indigo;
`