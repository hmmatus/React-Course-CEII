import React from 'react'

export const Form = props =>{
    const {username,pass,submitHandler,changeHandler} = props;
    return (
        <form onSubmit={submitHandler}>
            <h1>Nombre de usuario</h1>
            <input onChange={changeHandler} id={"username"} value={username} placeholder="Nombre de usuario"/>
            <input onChange={changeHandler} id={"pass"} value={pass} placeholder="Clave"/>
            <input type="submit"/>
        </form>
    )
}