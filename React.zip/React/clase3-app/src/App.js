import React, { Component } from 'react';
import { List } from './components/lists/list'
import { Form } from './components/form/form'
import './App.css'

const initState = {
      id:0,
      name: "",
      text: "",
      image: "",
      likes: 0
}

class App extends Component {
      constructor(props) {
            super(props);
            this.state = { ...initState, posts: [] }
            this.submitHandler = this.submitHandler.bind(this);
            this.changeHandler = this.changeHandler.bind(this);
            this.deleteHandler = this.deleteHandler.bind(this);
            this.addLikes = this.addLikes.bind(this);

      }
      submitHandler(event) {
            event.preventDefault();
            const { name, text, image, likes } = this.state;
            const posts = [...this.state.posts];
            console.log(posts.length)
            const id = posts.length+1
            console.log(id)
            posts.push({
                  id,name, text, image, likes
            });
            this.setState({
                  ...initState,
                  posts
            })
      }
      changeHandler(event) {
            //console.log(this.state.posts);
            const id = event.target.id;
            const value = event.target.value;
            this.setState({
                  [id]: value
            })
      }
      addLikes(setIndex) {
            console.log(this.state.posts);
            const newPosts = this.state.posts;
            newPosts.forEach(element => {
                  if(element.id === setIndex){
                        element["likes"]++;
                        
                  }
            });
            this.setState({
                  posts:newPosts
            })
      }
      deleteHandler(delIndex) {
            const newPosts = this.state.posts.filter((post, index) => {
                  return delIndex !== index;
            })
            this.setState({
                  posts: newPosts
            })
      }
      render() {
            const { name, text, image, likes, posts } = this.state;
            console.log(this.state.posts)
            return (
                  <div className="container">
                        <Form
                              name={name}
                              text={text}
                              image={image}
                              likes={likes}
                              changeHandler={this.changeHandler}
                              submitHandler={this.submitHandler}
                        />
                        <List posts={posts} deleteHandler={this.deleteHandler} addLikes={this.addLikes} />
                  </div>
            )
      }
}

export default App;
