export const posts = [
    {
      "name": "Raul Granados",
      "text": "JAJAKAKAKAKAKA",
      "image": "https://i.ytimg.com/vi/E-c0hsjee7g/maxresdefault.jpg",
      "likes": 20
    },
    {
      "name": "Raul Granados",
      "text": "XDDDDDDD",
      "image": "https://scontent-mia3-2.xx.fbcdn.net/v/t1.0-9/83792372_2492140531116235_4781817086135500800_n.jpg?_nc_cat=103&_nc_ohc=AJiGVXfJh7YAX8gnTKN&_nc_ht=scontent-mia3-2.xx&oh=568b544a27b27cf27922817a31cc3f7b&oe=5EC16A78",
      "likes": 5
    },
    {
      "name": "Raul Granados",
      "text": "",
      "image": "https://scontent-mia3-2.xx.fbcdn.net/v/t1.0-9/86702696_110330377217846_6525805307048755200_n.jpg?_nc_cat=109&_nc_ohc=8zQnR3WZVBMAX9DfW7I&_nc_ht=scontent-mia3-2.xx&oh=c02df94f4bf8b53eb5bb2da6d151d261&oe=5EFD10C6",
      "likes": 5
    },
    {
      "name": "Raul Granados",
      "text": "",
      "image": "https://scontent-mia3-1.xx.fbcdn.net/v/t1.0-9/86726332_174779590610258_2736702965728411648_n.jpg?_nc_cat=1&_nc_ohc=TzDesF85fqYAX9Qx54C&_nc_ht=scontent-mia3-1.xx&oh=265b8b945c89301aa9a5e139657bf7ad&oe=5EB4AEAF",
      "likes": 7
    },
    {
      "name": "Raul Granados",
      "text": "en la uca 🤪",
      "image": "https://scontent-mia3-1.xx.fbcdn.net/v/t1.0-9/86286239_2977733022247411_1765006141592436736_n.jpg?_nc_cat=1&_nc_ohc=3qorAKuJyNsAX_BaSLY&_nc_ht=scontent-mia3-1.xx&oh=af8ecf7e22427bca2f4af39e4d68611a&oe=5F003E63",
      "likes": 7
    },
    {
      "name": "Raul Granados",
      "text": "",
      "image": "https://scontent-mia3-2.xx.fbcdn.net/v/t1.0-9/69348212_2435090936816239_6089920977532092416_n.jpg?_nc_cat=105&_nc_ohc=EI4ndoAccKQAX84XXZg&_nc_ht=scontent-mia3-2.xx&oh=9b8c5011397368094a7b75c9f361c73f&oe=5F033E18",
      "likes": 4
    },
    {
      "name": "Raul Granados",
      "text": "",
      "image": "https://scontent-mia3-1.xx.fbcdn.net/v/t1.0-9/84398056_3536187176455070_1426938408046952448_n.jpg?_nc_cat=1&_nc_ohc=Ey8t4-t6xCIAX_8sBHY&_nc_ht=scontent-mia3-1.xx&oh=d61bc4b1922550dfc0afe2ac36e3405b&oe=5EB6A17F",
      "likes": 13
    },
    {
      "name": "Raul Granados",
      "text": "",
      "image": "https://scontent-mia3-1.xx.fbcdn.net/v/t1.0-9/85129473_147193086747432_6071817024659521536_n.jpg?_nc_cat=108&_nc_ohc=gPnKoB8r4sUAX9yAGet&_nc_ht=scontent-mia3-1.xx&oh=f609b92373600aa0d61e2e088f8552fb&oe=5EC60530",
      "likes": 3
    },
    {
      "name": "Raul Granados",
      "text": "",
      "image": "https://scontent-mia3-2.xx.fbcdn.net/v/t1.0-9/86382693_2952197264846518_1311471141461688320_n.jpg?_nc_cat=109&_nc_ohc=-PEkbyP1crMAX8W_A2a&_nc_ht=scontent-mia3-2.xx&oh=d000c861d4dc89fbd8fee865f2876610&oe=5ECAA79F",
      "likes": 5
    },
    {
      "name": "Raul Granados",
      "text": "",
      "image": "https://scontent-mia3-1.xx.fbcdn.net/v/t1.0-9/86410014_501861820522831_7768848720312926208_o.jpg?_nc_cat=1&_nc_ohc=0u2tdFSEO_AAX-MTtBc&_nc_ht=scontent-mia3-1.xx&oh=3a37ebd24adf1d65abf1e26b7aec2f48&oe=5EBA0E8B",
      "likes": 13
    },
    {
      "name": "Raul Granados",
      "text": "ahuevo :'v",
      "image": "https://scontent-mia3-1.xx.fbcdn.net/v/t1.0-9/86609136_2611631992415816_4600753707456397312_n.jpg?_nc_cat=1&_nc_ohc=EhP_CIWdW84AX8X1cqx&_nc_ht=scontent-mia3-1.xx&oh=200a3690484070f865643283d8bf3c3f&oe=5EB981C7",
      "likes": 7
    }
  ]