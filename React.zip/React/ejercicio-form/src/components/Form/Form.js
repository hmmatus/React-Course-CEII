import React from 'react';

export const Form = (props) => {
    const {name,lastName,age,carnet,changeHandler,submitHandler} = props;
    return (
        <form onSubmit={submitHandler}>
            <input onChange={changeHandler} id="name" placeholder="Nombre" value={name} />
            <input onChange={changeHandler} id="lastName" placeholder="Apellido" value={lastName}/>
            <input onChange={changeHandler} id="age" placeholder="Edad" value={age}/>
            <input onChange={changeHandler} id="carnet" placeholder="Carnet" value={carnet}/>
            <button type="submit">Guardar</button>
        </form>
    )
}