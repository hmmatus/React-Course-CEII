import React from 'react'
import { container } from './List.module.css'
import { Item } from './Item/Item'

export const List = props => {
    return (
        <div className={container}>
            {props.peoples.map((person, index) => (

            
                <Item
                    key={index}
                    {...person}
                    deleteHandler={() => props.deleteHandler(index)}
                />
            ))}
        </div>
    )
}
