import React, { Component } from 'react';
import './App.css';
import Register from './components/register'

class App extends Component {
  constructor(props) {
    super(props)

    this.state = {

    }
  }

  fetchData = () => {
    fetch("https://regres.in/api/users?page=2")
      .then(res => res.json())
      .then(data => {
        console.log(data);
      })
  }

  render() {
    //this.fetchData();
    return (
      <div className="App">
        <Register />
      </div>
    );
  }
}

export default App;
