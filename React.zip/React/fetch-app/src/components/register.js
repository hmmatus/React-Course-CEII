import React, { Component } from 'react'
const initState = {
    username: "",
    email: "",
    password: "",
}
export default class Register extends Component {
    constructor(props) {
        super(props)

        this.state = {
            ...initState
        }
    }

    changeHandler = event => {
        this.setState({
            [event.target.id]: event.target.value
        })
    }

    submitHandler=event=>{
        event.preventDefault();//Quita recargar pagina
        const user = this.state;
        console.log(user);
        let config={
            method:'POST',
            headers:{
                'content-type':'Application/json',
            },
            body:JSON.stringify(user),
        }
        fetch('https://reactcourseapi.herokuapp.com/user/register',config)
        .then(res=>res.json())
        .then(data=>{
            console.log("Entro a then")
            localStorage.setItem('token',data.token);
            this.setState({
                ...initState
            })
        })
        .catch(err=>{
            console.log(err)
        })
    }
    render() {
        const { username, email, password } = this.state
        return (
            <>
                <h1>Form</h1>
                <form onSubmit={this.submitHandler}>
                    <label>Username:
                    <input
                            type="text"
                            id="username"
                            value={username} 
                            onChange={this.changeHandler}/>
                    </label>
                    <label>E-mail:
                    <input
                            type="text"
                            id="email"
                            value={email} 
                            onChange={this.changeHandler}/>
                    </label>
                    <label>Password:
                    <input
                            type="password"
                            id="password"
                            value={password} 
                            onChange={this.changeHandler}/>
                    </label>
                    <button type="submit">Register</button>
                </form>
            </>
        )
    }
}