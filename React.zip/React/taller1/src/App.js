import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.css';
//import { List } from './components/lists/list'
import { Form } from './components/form/form'
import { Table } from './components//table/table'
import './App.css'

const initState = {
  id: 0,
  nombre: "",
  carnet: "000",
  tarde: true,

}

class App extends Component {
  constructor(props) {
    super(props);
    this.state = { ...initState, students: [] }
    this.submitHandler = this.submitHandler.bind(this);
    this.changeHandler = this.changeHandler.bind(this);
    this.deleteHandler = this.deleteHandler.bind(this);

  }
  submitHandler(event) {
    event.preventDefault();
    const { nombre, carnet, tarde } = this.state;
    console.log(tarde);
    const students = [...this.state.students];
    const id = students.length + 1
    students.push({
      id, nombre, carnet, tarde: tarde === 'true' ? true : false
    });
    this.setState({
      ...initState,
      students: students
    })
  }
  changeHandler(event) {
    console.log(this.state.students);
    const id = event.target.id;
    const value = event.target.value;
    this.setState({
      [id]: value
    })
  }
  deleteHandler(delIndex) {
    const newStudent = this.state.students.filter((student, index) => {
      return delIndex !== index;
    })
    this.setState({
      students: newStudent
    })
  }
  render() {
    const { id,nombre, carnet, tarde, students } = this.state;
    return (
      <div className="container">
          <Form
            nombre={nombre}
            carnet={carnet}
            tarde={tarde}
            changeHandler={this.changeHandler}
            submitHandler={this.submitHandler}
          />
          <Table
            key={id}
            students={students}
            deleteHandler={this.deleteHandler}
          />
      </div>
    )
  }
}

export default App;
