import React from 'react'
import 'bootstrap/dist/css/bootstrap.css';
//import '../../App.css'

export const Form = (props) => {
    const { nombre, carnet, tarde, changeHandler, submitHandler } = props;
    return (
        <form className="container" onSubmit={submitHandler}>
            <div>
                <input className="form-control" onChange={changeHandler} id="nombre" placeholder="Nombre" value={nombre} />
                <input className="form-control" onChange={changeHandler} id="carnet" placeholder="carnet" value={carnet} />
                <select value={tarde} className="form-control" id="tarde" onChange={changeHandler}>
                    <option value={true}>Tarde</option>
                    <option value={false}>A tiempo</option>
                </select>
            </div>
            <button type="submit" className="btn btn-primary">Guardar</button>
        </form>
    )
}