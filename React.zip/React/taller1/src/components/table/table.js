import React from 'react'
import 'bootstrap/dist/css/bootstrap.css';

export const Table = props => {
    return (
        <table className="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nombre</th>
                    <th>Carnet</th>
                    <th>Llego tarde?</th>
                </tr>
            </thead>
            <tbody>
                {props.students.map((element, index) => {
                    console.log(element)
                    return (
                        <tr>
                            <td>{element.id}</td>
                            <td>{element.nombre}</td>
                            <td>{element.carnet}</td>
                            <td>{element.tarde?"Tarde":"A tiempo"}</td>
                            <td><span className="btn btn-secondary" onClick={()=>props.deleteHandler(index)}>Eliminar</span></td>
                        </tr>
                    )
                })}
            </tbody>
        </table>
    )
}